<?php

$twig->display('newcomer.html.twig');
