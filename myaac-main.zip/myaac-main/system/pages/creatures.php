<?php

require 'monsters.php';
