<?php

require 'ots-info.php';
