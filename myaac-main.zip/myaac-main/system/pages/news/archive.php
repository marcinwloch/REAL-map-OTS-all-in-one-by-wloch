<?php
/**
 * News archive
 *
 * @package   MyAAC
 * @author    Gesior <jerzyskalski@wp.pl>
 * @author    Slawkens <slawkens@gmail.com>
 * @copyright 2019 MyAAC
 * @link      https://my-aac.org
 */
$_GET['archive'] = true;
require __DIR__ . '/../news.php';
