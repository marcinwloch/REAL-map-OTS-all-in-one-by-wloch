<?php

require __DIR__ . '/../common.php';
if(IS_CLI) {
	echo MYAAC_VERSION;
}
