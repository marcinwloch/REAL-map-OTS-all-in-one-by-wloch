<?php
/**
 * Custom functions
 *
 * @package   MyAAC
 * @author    Slawkens <slawkens@gmail.com>, Lee
 * @copyright 2020 MyAAC
 * @link      https://my-aac.org
 */

// Insert your custom functions here.
