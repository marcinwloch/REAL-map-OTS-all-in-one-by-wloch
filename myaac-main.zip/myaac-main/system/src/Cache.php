<?php

namespace MyAAC;

class Cache extends Cache\Cache {}
