<?php

namespace MyAAC\Exceptions;

class SensitiveException extends \Exception
{
}
