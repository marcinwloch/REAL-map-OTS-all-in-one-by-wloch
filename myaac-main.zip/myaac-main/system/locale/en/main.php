<?php
/**
 * english language file
 * main.php
 *
 * @author Slawkens <slawkens@gmail.com>
 */
$locale['name']     = 'English';
$locale['lang']		= 'en';
$locale['encoding'] = 'utf-8';
$locale['direction']= 'ltr';

$locale['error404'] = 'The requested page was not found.';
$locale['news'] = 'Latest news';
$locale['loaded_in_ms'] = 'in $TIME$ ms';