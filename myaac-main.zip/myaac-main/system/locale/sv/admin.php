<?php
/**
 * swedish language file
 * admin.php
 *
 * @author Sizaro <sizaro@live.se>
 */
$locale['title'] = 'MyAAC Admin';
