<?php
// this migration has been removed, but file kept for compatibility
