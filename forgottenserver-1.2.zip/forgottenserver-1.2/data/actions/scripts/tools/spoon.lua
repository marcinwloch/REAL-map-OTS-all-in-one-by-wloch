function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	return onUseSpoon(player, item, fromPosition, target, toPosition, isHotkey)
end
