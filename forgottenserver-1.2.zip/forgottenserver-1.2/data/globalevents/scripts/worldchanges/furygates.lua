function onStartup(interval)
	Game.setStorageValue(GlobalStorage.FuryGates, math.random(6))
end
