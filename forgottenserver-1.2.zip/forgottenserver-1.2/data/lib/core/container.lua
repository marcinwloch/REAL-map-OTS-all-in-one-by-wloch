function Container.isContainer(self)
	return true
end
