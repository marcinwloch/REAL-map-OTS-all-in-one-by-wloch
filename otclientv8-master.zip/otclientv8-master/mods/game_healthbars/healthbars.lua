function init()
  g_healthBars.addHealthBackground("/images/bars/health1", -2, -2, 0, 2, 4)
  g_healthBars.addManaBackground("/images/bars/mana1", -2, -2, 0, 2, 4)
end

function terminate()
end
